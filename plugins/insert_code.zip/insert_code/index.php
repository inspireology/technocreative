<?php

add_action('init', 'insert_code_buttons');
function insert_code_buttons()
{
    add_filter("mce_external_plugins", "insert_code_add_buttons");
    add_filter("mce_buttons", "insert_code_register_buttons");
}

function insert_code_add_buttons($plug_array)
{
    $plugin_array['insert_code'] = get_template_directory_uri(). '/plugins/insert_code/insert_code.js';
    return $plugin_array;
}

function insert_code_register_buttons($buttons)
{
    array_push($buttons, 'addCodeBlock', 'setCodeLanguage' );
    return $buttons;
}
